"""
Streamlit frontend that relies entirely on a separate REST backend.

This frontend no longer builds local models or indexes. It uploads documents
to the backend (`/documents/process`) and sends chat queries to the backend
(`/generate`). No local HuggingFace token or model is used.
"""

import streamlit as st
import requests
import os
import tempfile
from pathlib import Path

# Backend URL (configurable via env or sidebar)
BACKEND_URL = os.environ.get("BACKEND_URL", "http://localhost:8000")

st.set_page_config(page_title="RAG Chatbot", layout="wide")

# session state
for k, v in {
    "messages": [],
    "index_ready": False,
    "index_name": None,
    "doc_name": None,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v


def process_upload(uploaded_file):
    """Send uploaded file to backend /documents/process and update session state."""
    try:
        files = {"file": (uploaded_file.name, uploaded_file.getvalue())}
        data = {"chunk_size": 1000, "chunk_overlap": 200}
        resp = requests.post(f"{BACKEND_URL}/documents/process", files=files, data=data, timeout=180)
        if resp.status_code == 200:
            out = resp.json()
            st.session_state.index_ready = True
            st.session_state.index_name = out.get("index_name")
            st.session_state.doc_name = uploaded_file.name
            st.success(f"Indexed {uploaded_file.name}: {out.get('num_chunks')} chunks")
        else:
            st.error(f"Indexing failed: {resp.status_code} {resp.text}")
    except Exception as e:
        st.error(f"Error contacting backend: {e}")


# Sidebar: backend config + upload
with st.sidebar:
    st.header("Settings")
    backend_in = st.text_input("Backend URL", value=BACKEND_URL)
    if backend_in:
        BACKEND_URL = backend_in.rstrip("/")

    st.markdown("---")
    st.subheader("Upload Document (optional)")
    uploaded = st.file_uploader(
        "Supported: PDF, TXT, DOCX, CSV",
        type=["pdf", "txt", "docx", "csv"],
    )

    if uploaded:
        if st.button("Process uploaded document"):
            with st.spinner("Processing and indexing on backend..."):
                process_upload(uploaded)

    if st.session_state.get("doc_name"):
        st.markdown(f"**Active doc:** `{st.session_state.doc_name}`")
        if st.button("Clear document & chat"):
            for k in ("messages", "index_ready", "index_name", "doc_name"):
                st.session_state[k] = [] if k == "messages" else None
            st.experimental_rerun()

    st.markdown("---")
    st.caption("Frontend connects to a separate REST backend for processing and generation.")


# Main chat area
st.title("💬 InsiBot")

if not st.session_state.get("index_ready"):
    st.info("Upload & process a document in the sidebar, or ensure the backend has an existing index.")

# render chat history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])


def send_query_to_backend(question: str):
    # Some backends expect the field name `prompt` instead of `question`.
    # Send both keys for compatibility so older/newer backends accept the request.
    payload = {
        "index_name": st.session_state.get("index_name"),
        "prompt": question,
        "question": question,
        "top_k": 3,
    }
    try:
        r = requests.post(f"{BACKEND_URL}/generate", json=payload, timeout=180)
        if r.status_code == 200:
            out = r.json()
            answer = out.get("answer") or out.get("text") or "(no answer)"
            sources = out.get("sources", [])
            return answer, sources
        else:
            return f"Generation failed: {r.status_code} {r.text}", []
    except Exception as e:
        return f"Error contacting backend: {e}", []


if prompt := st.chat_input("Ask something about your document…"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Contacting backend..."):
            answer, sources = send_query_to_backend(prompt)
            st.markdown(answer)
            if sources:
                st.markdown("**Sources**")
                for s in sources:
                    st.write(f"- {s}")

    st.session_state.messages.append({"role": "assistant", "content": answer})


