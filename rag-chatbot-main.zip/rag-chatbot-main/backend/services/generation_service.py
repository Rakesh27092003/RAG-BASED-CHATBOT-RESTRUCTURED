from backend.utils.model_routing import get_generation_model
from typing import List, Dict


def generate_answer(prompt: str, context_chunks: List[Dict]) -> str:
    model = get_generation_model()
    # build a simple context string
    context = "\n\n".join([c.get("text", "") for c in context_chunks])
    full_prompt = f"""You are AI Assistant.Summarize the following retrieved information and answer the user's question based on it. 
                    If the retrieved information does not contain the answer, say you don't know. Be concise and accurate.\n\n
                    Retrieved Context:\n{context}\n\n
                    User Prompt:\n{prompt}\n\nAnswer:"""
    # Limit generation output to 2048 tokens
    return model.generate(full_prompt, max_tokens=2048)
