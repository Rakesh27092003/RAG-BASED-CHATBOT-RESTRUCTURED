from backend.utils.helpers import save_file_bytes, read_text_file
from pathlib import Path
from typing import Tuple
import fitz
import docx


def save_uploaded_file(storage_dir: str, filename: str, contents: bytes) -> str:
    path = save_file_bytes(storage_dir, filename, contents)
    return path


def extract_text_from_file(path: str) -> str:
    p = Path(path)
    ext = p.suffix.lower()
    if ext == ".txt":
        return read_text_file(path)
    if ext == ".pdf":
        try:
            doc = fitz.open(path)
            text = []
            for page in doc:
                text.append(page.get_text())
            return "\n".join(text)
        except Exception:
            return ""
    if ext in (".docx", ".doc"):
        try:
            doc = docx.Document(path)
            paragraphs = [p.text for p in doc.paragraphs]
            return "\n".join(paragraphs)
        except Exception:
            return ""
    # fallback
    return read_text_file(path)
