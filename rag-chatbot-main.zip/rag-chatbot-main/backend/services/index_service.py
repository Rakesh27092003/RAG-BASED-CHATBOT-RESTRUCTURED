import json
import numpy as np
from pathlib import Path
from typing import List
from backend.utils.helpers import index_storage_dir
from backend.configs.model_config import settings

try:
    import faiss
    _FAISS_AVAILABLE = True
except Exception:
    _FAISS_AVAILABLE = False


def persist_index(index_name: str, embeddings: List[List[float]], chunks: List[str], root_storage: str = None) -> str:
    # Use configured single shared index name when none provided
    if not index_name:
        index_name = settings.SINGLE_INDEX_NAME

    idx_dir = index_storage_dir(root_storage)
    idx_path = Path(idx_dir) / f"{index_name}.npz"
    index_file = Path(idx_dir) / f"{index_name}.index"
    meta_path = Path(idx_dir) / f"{index_name}_meta.json"
    arr = np.array(embeddings, dtype=np.float32)

    if _FAISS_AVAILABLE:
        dim = arr.shape[1]
        # If an index exists, load and append; otherwise create a new one
        if index_file.exists():
            index = faiss.read_index(str(index_file))
            # validate dimensions
            try:
                existing_dim = index.d
            except Exception:
                # fallback: try attribute 'ntotal' and shape checks are not possible
                existing_dim = dim
            if existing_dim != dim:
                raise ValueError(f"Embedding dimension mismatch: existing index dim={existing_dim} vs new dim={dim}")
            index.add(arr)
            faiss.write_index(index, str(index_file))
            # update meta by appending chunks
            if meta_path.exists():
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                meta_chunks = meta.get("chunks", [])
                meta_chunks.extend(chunks)
                meta["chunks"] = meta_chunks
                meta["num_chunks"] = len(meta_chunks)
            else:
                meta = {"chunks": chunks, "num_chunks": len(chunks), "use_faiss": True}
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f)
            return str(index_file)
        else:
            index = faiss.IndexFlatL2(dim)
            index.add(arr)
            faiss.write_index(index, str(index_file))
            meta = {"chunks": chunks, "num_chunks": len(chunks), "use_faiss": True}
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f)
            return str(index_file)
    else:
        # If npz exists, load and append embeddings; otherwise create a new file
        if idx_path.exists():
            data = np.load(str(idx_path), allow_pickle=True)
            existing = data["embeddings"]
            if existing.shape[1] != arr.shape[1]:
                raise ValueError(f"Embedding dimension mismatch: existing npz dim={existing.shape[1]} vs new dim={arr.shape[1]}")
            combined = np.concatenate([existing, arr], axis=0)
            np.savez_compressed(str(idx_path), embeddings=combined)
            # update meta
            if meta_path.exists():
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                meta_chunks = meta.get("chunks", [])
                meta_chunks.extend(chunks)
                meta["chunks"] = meta_chunks
                meta["num_chunks"] = len(meta_chunks)
            else:
                meta = {"chunks": chunks, "num_chunks": len(chunks), "use_faiss": False}
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f)
            return str(idx_path)
        else:
            np.savez_compressed(str(idx_path), embeddings=arr)
            meta = {"chunks": chunks, "num_chunks": len(chunks), "use_faiss": False}
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f)
            return str(idx_path)


def load_index(index_name: str, root_storage: str = None):
    idx_dir = index_storage_dir(root_storage)
    idx_path = Path(idx_dir) / f"{index_name}.npz"
    index_file = Path(idx_dir) / f"{index_name}.index"
    meta_path = Path(idx_dir) / f"{index_name}_meta.json"
    if not meta_path.exists():
        return None
    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    if meta.get("use_faiss") and _FAISS_AVAILABLE and index_file.exists():
        index = faiss.read_index(str(index_file))
        # return index and meta; search_service will handle faiss path
        return index, meta
    if idx_path.exists():
        data = np.load(str(idx_path), allow_pickle=True)
        embeddings = data["embeddings"]
        return embeddings, meta
    return None
