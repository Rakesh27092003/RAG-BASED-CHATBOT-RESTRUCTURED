import numpy as np
from typing import List, Dict
from backend.services.index_service import load_index


def _cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
    if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
        return 0.0
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


def search_index(query_embedding: List[float], index_name: str, top_k: int = 5, root_storage: str = None) -> List[Dict]:
    res = load_index(index_name, root_storage)
    if res is None:
        return []

    if hasattr(res[0], "search"):
        index, meta = res
        q = np.asarray(query_embedding, dtype=np.float32)
        if q.ndim == 1:
            q = q.reshape(1, -1)
        import faiss
        faiss.normalize_L2(q)
        distances, indices = index.search(q, top_k)
        out = []
        for score, idx in zip(distances[0].tolist(), indices[0].tolist()):
            if idx < 0:
                continue
            out.append({"chunk_id": int(idx), "score": float(score), "text": meta["chunks"][idx]})
        return out

    embeddings, meta = res
    embeddings = np.asarray(embeddings, dtype=np.float32)
    q = np.asarray(query_embedding, dtype=np.float32)
    scores = []
    for i, emb in enumerate(embeddings):
        scores.append((i, _cosine_sim(q, emb)))
    scores.sort(key=lambda x: x[1], reverse=True)
    out = []
    for idx, score in scores[:top_k]:
        out.append({"chunk_id": int(idx), "score": float(score), "text": meta["chunks"][idx]})
    return out
