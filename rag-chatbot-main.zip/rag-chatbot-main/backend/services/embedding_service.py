from backend.utils.model_routing import get_embedding_model
from typing import List


def embed_texts(texts: List[str]):
    model = get_embedding_model()
    return model.embed_texts(texts)
