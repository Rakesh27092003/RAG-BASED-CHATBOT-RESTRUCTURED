from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os
from pathlib import Path
from backend.configs.model_config import settings

from backend.routers import documents, search, generate, indexes
from backend.routers import models

app = FastAPI(title="RAG Chatbot Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ROOT = Path(__file__).resolve().parents[1]
STORAGE = Path(settings.FILE_STORAGE_PATH)
INDEXES = STORAGE / "indexes"


@app.on_event("startup")
async def startup_event():
    os.makedirs(STORAGE, exist_ok=True)
    os.makedirs(INDEXES, exist_ok=True)


app.include_router(documents.router, prefix="/documents", tags=["documents"])
app.include_router(search.router, prefix="", tags=["search"])
app.include_router(generate.router, prefix="", tags=["generate"])
app.include_router(indexes.router, prefix="", tags=["indexes"])
app.include_router(models.router, prefix="", tags=["models"])


@app.get("/")
async def root():
    return {"status": "ok", "message": "RAG Chatbot Backend"}
