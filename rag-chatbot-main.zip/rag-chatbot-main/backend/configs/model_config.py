from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Use Gemini by default for both embeddings and generation
    PROVIDER: str = "gemini"
    EMBEDDING_PROVIDER: str = "gemini"
    GENERATION_PROVIDER: str = "gemini"
    # Default model ids
    # `MODEL_ID` is the general fallback; set to a text-generation model by default
    MODEL_ID: str = "gemini-3"
    EMBEDDING_MODEL_ID: Optional[str] = "gemini-embedding-001"
    # Use a supported generation model; change to your account's available model if needed
    # Default set to `text-bison-001`. If your account supports Gemini models, replace with an appropriate model id.
    GENERATION_MODEL_ID: Optional[str] = "text-bison-001"
    ANTHROPIC_API_KEY: Optional[str] = None
    GEMINI_API_KEY: Optional[str] = None
    FILE_STORAGE_PATH: str = "./uploaded_files"
    # Name of the single shared index file (can be overridden)
    SINGLE_INDEX_NAME: str = "main_index"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
