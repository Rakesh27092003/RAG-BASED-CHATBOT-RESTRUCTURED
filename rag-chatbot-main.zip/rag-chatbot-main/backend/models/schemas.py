from pydantic import BaseModel
from typing import List, Optional


# Minimal schemas currently used by the API routers.
class SearchResult(BaseModel):
    chunk_id: int
    score: float
    text: str


class SearchRequest(BaseModel):
    query: str
    top_k: int = 5


class GenerateRequest(BaseModel):
    prompt: str
    top_k: int = 5


class GenerateResponse(BaseModel):
    answer: str
    source_chunks: List[SearchResult] = []
