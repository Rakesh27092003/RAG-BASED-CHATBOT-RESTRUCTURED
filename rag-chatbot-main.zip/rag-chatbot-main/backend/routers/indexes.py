from fastapi import APIRouter
from backend.services.index_service import load_index
from backend.configs.model_config import settings

router = APIRouter()


@router.get("/indexes/current")
async def current_index():
    """Return metadata about the single shared index (exists, num_chunks)."""
    res = load_index(settings.SINGLE_INDEX_NAME, root_storage=settings.FILE_STORAGE_PATH)
    if not res:
        return {"index_exists": False, "index_name": settings.SINGLE_INDEX_NAME}
    # load_index returns (index_or_embeddings, meta)
    _, meta = res
    return {
        "index_exists": True,
        "index_name": settings.SINGLE_INDEX_NAME,
        "num_chunks": meta.get("num_chunks", 0),
        "use_faiss": meta.get("use_faiss", False),
    }
