from fastapi import APIRouter, HTTPException
from backend.configs.model_config import settings

router = APIRouter()


@router.get("/models/list")
async def list_models():
    """List available Google GenAI models visible to the configured API key.

    Returns a permissive structure describing model ids and any advertised
    supported methods so the operator can pick a suitable model for
    embedding or generation.
    """
    try:
        from google import genai
    except Exception:
        raise HTTPException(status_code=500, detail="google-genai SDK not installed")

    if not settings.GEMINI_API_KEY:
        raise HTTPException(status_code=400, detail="GEMINI_API_KEY not configured")

    client = genai.Client(api_key=settings.GEMINI_API_KEY)

    # Try a couple of possible list APIs and be permissive with response parsing
    models = []
    try:
        # Preferred: client.list_models()
        resp = getattr(client, "list_models", None)
        if callable(resp):
            out = client.list_models()
            # try to extract an iterable of model objects
            iterable = getattr(out, "models", None) or out
        else:
            # fallback to client.models.list() if present
            models_api = getattr(client, "models", None)
            if models_api and hasattr(models_api, "list"):
                out = client.models.list()
                iterable = getattr(out, "models", None) or out
            else:
                raise RuntimeError("No list models API found on genai client")

        for m in iterable:
            # permissive extraction
            mid = getattr(m, "name", None) or getattr(m, "id", None) or str(m)
            supported = getattr(m, "supported_methods", None) or getattr(m, "methods", None) or []
            models.append({"id": mid, "supported_methods": supported})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list models: {e}")

    return {"models": models}


@router.get("/models/auto_pick")
async def auto_pick_model():
    """Attempt to pick a model that supports generation (`generateContent`).

    Returns the first model advertising support for generateContent (or similar).
    """
    # Auto-pick removed — prefer explicit model configuration in `.env` / settings.
    raise HTTPException(status_code=410, detail="Auto-pick removed; set GENERATION_MODEL_ID in configuration.")
