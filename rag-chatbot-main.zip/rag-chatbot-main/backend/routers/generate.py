from fastapi import APIRouter, HTTPException
from backend.models.schemas import GenerateRequest, SearchResult, GenerateResponse
from backend.services.embedding_service import embed_texts
from backend.services.search_service import search_index
from backend.services.generation_service import generate_answer
from backend.configs.model_config import settings

router = APIRouter()

@router.post("/generate")
async def generate(req: GenerateRequest):
    # embed the prompt
    query_emb = embed_texts([req.prompt])[0]
    # Use the single shared index name from settings (do not ask client)
    index_name = settings.SINGLE_INDEX_NAME
    sources = search_index(query_emb, index_name, top_k=req.top_k, root_storage=settings.FILE_STORAGE_PATH)
    answer = generate_answer(req.prompt, sources)
    return {"answer": answer, "source_chunks": sources}
