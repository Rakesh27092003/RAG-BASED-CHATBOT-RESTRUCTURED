from fastapi import APIRouter, UploadFile, File, HTTPException
from backend.services.document_service import save_uploaded_file, extract_text_from_file
from backend.utils.chunking import split_text
from backend.services.embedding_service import embed_texts
from backend.services.index_service import persist_index
from backend.configs.model_config import settings
from pathlib import Path
from typing import Optional
import uuid

router = APIRouter()


@router.post("/process")
async def process(
    file: Optional[UploadFile] = File(None),
    filename: Optional[str] = None,
    index_name: Optional[str] = None,
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
):
    """Single endpoint that accepts an uploaded file or existing filename, extracts text,
    splits into chunks, creates embeddings and persists an index. Returns index metadata.

    - If `file` is provided it will be saved to storage and processed.
    - Otherwise `filename` must point to an existing file under `settings.FILE_STORAGE_PATH`.
    """
    storage = settings.FILE_STORAGE_PATH

    # Save uploaded file when provided
    if file is not None:
        contents = await file.read()
        filename = f"{uuid.uuid4().hex}_{file.filename}"
        save_uploaded_file(storage, filename, contents)

    if not filename:
        raise HTTPException(status_code=400, detail="filename or file upload is required")

    path = Path(storage) / filename
    if not path.exists():
        raise HTTPException(status_code=404, detail="file not found")

    # Extract and chunk
    text = extract_text_from_file(str(path))
    chunks = split_text(text, chunk_size=chunk_size, overlap=chunk_overlap)

    # Create embeddings (handled by embedding_service)
    embeddings = embed_texts(chunks)

    # Persist index (uses FAISS if available else compressed npz)
    # Always use the shared index name by default unless an explicit index_name is provided
    if index_name is None:
        index_name = settings.SINGLE_INDEX_NAME
    index_path = persist_index(index_name, embeddings, chunks, root_storage=storage)

    return {"index_name": index_name, "num_chunks": len(chunks), "index_path": index_path}
