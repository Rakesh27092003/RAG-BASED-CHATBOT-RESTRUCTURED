from fastapi import APIRouter, HTTPException
from backend.models.schemas import SearchRequest
from backend.services.search_service import search_index
from backend.services.embedding_service import embed_texts
from backend.configs.model_config import settings

router = APIRouter()

@router.post("/search")
async def search(req: SearchRequest):
    query_embedding = embed_texts([req.query])[0]
    # Always search the single shared index; do not accept index name from client
    index_name = settings.SINGLE_INDEX_NAME
    results = search_index(query_embedding, index_name, top_k=req.top_k, root_storage=settings.FILE_STORAGE_PATH)
    if results is None:
        raise HTTPException(status_code=404, detail="index not found")
    return {"query": req.query, "index_name": index_name, "results": results}
