import os
from pathlib import Path
from typing import Optional


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def save_file_bytes(storage_dir: str, filename: str, contents: bytes) -> str:
    ensure_dir(storage_dir)
    path = Path(storage_dir) / filename
    with open(path, "wb") as f:
        f.write(contents)
    return str(path)


def read_text_file(path: str) -> str:
    ext = Path(path).suffix.lower()
    if ext == ".txt":
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    # add other loaders (pdf/docx) as needed
    return ""


def index_storage_dir(root_storage: Optional[str] = None) -> str:
    base = root_storage or "./uploaded_files"
    idx = Path(base) / "indexes"
    ensure_dir(str(idx))
    return str(idx)
