from backend.configs.model_config import settings
from typing import List
from pathlib import Path
import logging


class BaseModelClient:
    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        raise NotImplementedError()

    def generate(self, prompt: str, **kwargs) -> str:
        raise NotImplementedError()


class GeminiModel(BaseModelClient):
    """Lightweight Gemini client using the official google-genai SDK.

    This implementation assumes the model IDs in `settings` are valid for
    your account and compatible with the SDK. It does not perform any model
    discovery or automatic fallback.
    """
    def __init__(self, model_id: str):
        self.model_id = model_id
        self.api_key = settings.GEMINI_API_KEY

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        if not self.api_key:
            raise RuntimeError("GEMINI_API_KEY is required for Gemini embeddings.")
        try:
            from google import genai
        except Exception as e:
            raise RuntimeError("The 'google-genai' package is not installed. Run 'pip install google-genai'.") from e

        client = genai.Client(api_key=self.api_key)
        resp = client.models.embed_content(model=self.model_id, contents=texts)

        # Extract embeddings (SDK returns an object; be permissive)
        sdk_embs = getattr(resp, "embeddings", None) or getattr(resp, "embedding", None)
        if sdk_embs is None:
            # Fallback: try treating resp as an iterable of vectors
            try:
                return [list(map(float, vec)) for vec in resp]
            except Exception:
                raise RuntimeError("Unexpected embedding response format from Gemini SDK")

        result = []
        for emb in sdk_embs:
            if isinstance(emb, (list, tuple)):
                vec = [float(x) for x in emb]
            else:
                # common attribute names
                vec = None
                for attr in ("embedding", "values", "value"):
                    if hasattr(emb, attr):
                        vec = getattr(emb, attr)
                        break
                if vec is None:
                    try:
                        vec = list(emb)
                    except Exception:
                        raise RuntimeError(f"Unable to parse embedding object: {type(emb)}")
                vec = [float(x) for x in vec]
            result.append(vec)
        return result

    def generate(self, prompt: str, **kwargs) -> str:
        if not self.api_key:
            raise RuntimeError("GEMINI_API_KEY is required for Gemini generation.")
        try:
            from google import genai
        except Exception as e:
            raise RuntimeError("The 'google-genai' package is not installed. Run 'pip install google-genai'.") from e
        client = genai.Client(api_key=self.api_key)

        def _extract_text_from_resp(resp_obj):
            if hasattr(resp_obj, "text") and resp_obj.text:
                return resp_obj.text
            if hasattr(resp_obj, "candidates") and resp_obj.candidates:
                cand = resp_obj.candidates[0]
                return getattr(cand, "content", getattr(cand, "output", str(cand)))
            if hasattr(resp_obj, "outputs") and resp_obj.outputs:
                out = resp_obj.outputs[0]
                return getattr(out, "text", getattr(out, "content", str(out)))
            return str(resp_obj)

        # Respect max tokens (default to 2048)
        max_tokens = int(kwargs.get("max_tokens", 2048))
        try:
            # Pass common SDK parameter name `max_output_tokens` when available
            try:
                resp = client.models.generate_content(model=self.model_id, contents=prompt, max_output_tokens=max_tokens)
            except TypeError:
                # SDK may not accept the kwarg; try without it
                resp = client.models.generate_content(model=self.model_id, contents=prompt)
            return _extract_text_from_resp(resp)
        except Exception as e:
            # If it's a 404 for unsupported model/method, try to find another model that supports generation
            try:
                # attempt to import SDK error class for more specific handling
                from google.genai.errors import ClientError as GenAIClientError
            except Exception:
                GenAIClientError = None

            is_not_found = False
            if GenAIClientError and isinstance(e, GenAIClientError):
                # SDK-specific error
                is_not_found = getattr(e, 'status_code', None) == 404 or getattr(e, 'code', None) == 404
            else:
                # Fallback: inspect message
                msg = str(e).lower()
                is_not_found = 'not found' in msg or 'not_supported' in msg or '404' in msg

            if not is_not_found:
                raise

            # Try listing models and find one that advertises generation support
            try:
                models_list = []
                if hasattr(client, 'list_models') and callable(getattr(client, 'list_models')):
                    out = client.list_models()
                    models_list = getattr(out, 'models', out) or []
                elif hasattr(client, 'models') and hasattr(client.models, 'list'):
                    out = client.models.list()
                    models_list = getattr(out, 'models', out) or []

                # Permissive extraction of supported methods
                candidate_model = None
                for m in models_list:
                    methods = getattr(m, 'supported_methods', None) or getattr(m, 'methods', None) or []
                    # normalize methods to strings
                    methods_l = [str(x).lower() for x in methods]
                    if any('generate' in mm or 'chat' in mm for mm in methods_l):
                        candidate_model = getattr(m, 'name', None) or getattr(m, 'id', None) or str(m)
                        break

                if candidate_model:
                    # retry once with candidate model (respecting max_tokens)
                    try:
                        resp2 = client.models.generate_content(model=candidate_model, contents=prompt, max_output_tokens=max_tokens)
                    except TypeError:
                        resp2 = client.models.generate_content(model=candidate_model, contents=prompt)
                    result_text = _extract_text_from_resp(resp2)

                    # Persist the discovered generation model to .env so future runs use it
                    try:
                        repo_root = Path(__file__).resolve().parents[2]
                        env_path = repo_root / ".env"
                        if env_path.exists():
                            txt = env_path.read_text(encoding="utf-8")
                            lines = txt.splitlines()
                            updated = False
                            for i, ln in enumerate(lines):
                                if ln.strip().startswith("GENERATION_MODEL_ID="):
                                    lines[i] = f"GENERATION_MODEL_ID={candidate_model}"
                                    updated = True
                                    break
                            if not updated:
                                lines.append(f"GENERATION_MODEL_ID={candidate_model}")
                            env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
                        else:
                            env_path.write_text(f"GENERATION_MODEL_ID={candidate_model}\n", encoding="utf-8")
                        # update in-memory settings so runtime uses the new model immediately
                        try:
                            settings.GENERATION_MODEL_ID = candidate_model
                        except Exception:
                            pass
                        logging.info(f"Updated .env GENERATION_MODEL_ID -> {candidate_model}")
                    except Exception as wf:
                        logging.warning(f"Failed to persist discovered generation model: {wf}")

                    return result_text
            except Exception:
                pass

            # re-raise original error if fallback failed
            raise


class AnthropicModel(BaseModelClient):
    """Simple Anthropic client using the HTTP API (keeps dependency footprint small).

    Assumes `ANTHROPIC_API_KEY` and model IDs are configured in `settings`.
    """
    def __init__(self, model_id: str):
        self.model_id = model_id
        self.api_key = settings.ANTHROPIC_API_KEY
        self.base_url = "https://api.anthropic.com/v1"

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        if not self.api_key:
            raise RuntimeError("ANTHROPIC_API_KEY is required for Anthropic embeddings.")
        import httpx
        url = f"{self.base_url}/embeddings"
        headers = {"Content-Type": "application/json", "x-api-key": self.api_key}
        payload = {"model": self.model_id, "input": texts}
        resp = httpx.post(url, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        return [item.get("embedding", []) for item in data.get("data", [])]

    def generate(self, prompt: str, **kwargs) -> str:
        if not self.api_key:
            raise RuntimeError("ANTHROPIC_API_KEY is required for Anthropic generation.")
        import httpx
        url = f"{self.base_url}/complete"
        headers = {"Content-Type": "application/json", "x-api-key": self.api_key}
        payload = {
            "model": self.model_id,
            "prompt": prompt,
            "max_tokens_to_sample": kwargs.get("max_tokens", 2048),
            "temperature": kwargs.get("temperature", 0.2),
        }
        resp = httpx.post(url, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        return data.get("completion", "")


def get_embedding_model() -> BaseModelClient:
    """Return an embedding model client based on settings.

    This function reads `EMBEDDING_PROVIDER` and `EMBEDDING_MODEL_ID` from
    `settings` (falling back to `PROVIDER` / `MODEL_ID`) and returns a
    simple client. It does not perform discovery or validation.
    """
    provider = settings.EMBEDDING_PROVIDER.lower() if settings.EMBEDDING_PROVIDER else settings.PROVIDER.lower()
    model_id = settings.EMBEDDING_MODEL_ID or settings.MODEL_ID
    if provider == "gemini":
        return GeminiModel(model_id)
    elif provider == "anthropic":
        return AnthropicModel(model_id)
    else:
        raise ValueError(f"Unsupported embedding provider: {settings.EMBEDDING_PROVIDER}")


def get_generation_model() -> BaseModelClient:
    """Return a generation model client based on settings.

    Reads `GENERATION_PROVIDER` and `GENERATION_MODEL_ID` from `settings`.
    """
    provider = settings.GENERATION_PROVIDER.lower() if settings.GENERATION_PROVIDER else settings.PROVIDER.lower()
    model_id = settings.GENERATION_MODEL_ID or settings.MODEL_ID
    if provider == "gemini":
        return GeminiModel(model_id)
    elif provider == "anthropic":
        return AnthropicModel(model_id)
    else:
        raise ValueError(f"Unsupported generation provider: {settings.GENERATION_PROVIDER}")
